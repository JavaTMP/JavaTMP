create definer = root@localhost trigger accountTransaction_del_tri
    after delete
    on accounttransaction
    for each row
BEGIN
    Declare entryAmount DECIMAL(33,8);
    DECLARE transactionDate DATETIME;

    select te.entryAmount, te.`entryDate`
    into entryAmount, transactionDate
    from transactionEntry te
    where te.id = old.id
    for update;

    update transactionEntry t
    set t.accountBalance = t.accountBalance - entryAmount
    where ( (entryDate > transactionDate) or (entryDate = transactionDate and id > old.id))
    and `accountId` = old.accountId;

    delete from transactionEntry where id = old.id;
END;

