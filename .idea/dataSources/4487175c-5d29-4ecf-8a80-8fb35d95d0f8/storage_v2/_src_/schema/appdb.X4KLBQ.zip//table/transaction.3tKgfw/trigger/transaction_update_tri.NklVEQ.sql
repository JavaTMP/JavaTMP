create definer = root@localhost trigger transaction_update_tri
    after update
    on transaction
    for each row
BEGIN
    
    DECLARE done INT DEFAULT FALSE;

    
    DECLARE currentTransactionId BIGINT UNSIGNED;
    Declare id BIGINT UNSIGNED;
    Declare accountId BIGINT UNSIGNED;
    Declare entryAmount DECIMAL(33,8);
    DECLARE oldTransactionEntryDate DATETIME;
    Declare accountBalance DECIMAL(33,8) DEFAULT 0;

    DECLARE transactionEntriesCursor CURSOR FOR
    select te.id,te.`accountId`, te.entryAmount
    from transactionEntry te
    where te.`transactionId` = currentTransactionId
    for update;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

insert into log (description) values (CONCAT('start trigger for transactionId=', old.id,
', oldDate=', old.transactionDate, ' newDate=', NEW.transactionDate));
    IF (OLD.transactionDate <> NEW.transactionDate) THEN
        set currentTransactionId = old.id;
        OPEN transactionEntriesCursor;
        read_loop: LOOP
            set done = false;
            
            FETCH transactionEntriesCursor
            INTO id, accountId, entryAmount;
            
            IF done THEN
                LEAVE read_loop;
            END IF;
            insert into log (description) values (CONCAT('transactionId=', old.id, ',entryId=', id, ',accountid=', accountId));
            
            update transactionEntry t
            set t.accountBalance = t.accountBalance - entryAmount
            where ( (t.entryDate > OLD.transactionDate) or (t.entryDate = OLD.transactionDate and t.id > id))

            and t.`accountId` = accountId;

            insert into log (description) values (CONCAT('after update old entries transactionId=', old.id, ',entryId=', id, ',accountid=', accountId));

            update transactionEntry t set t.accountBalance = t.accountBalance + entryAmount
            where ((t.entryDate > NEW.transactionDate) or (t.entryDate = NEW.transactionDate and t.id > id) )

            and t.`accountId` = accountId;

            insert into log (description) values (CONCAT('after update new entries transactionId=', old.id, ',entryId=', id, ',accountid=', accountId));

            set accountBalance = 0;
            select IFNULL(t.`accountBalance`, 0)
            into accountBalance
            from transactionEntry t
            where ((t.entryDate < NEW.transactionDate) or (t.entryDate = NEW.transactionDate and t.id < id) )
            and t.`accountId` = accountId

            order by t.`entryDate` desc, t.id desc
            limit 1
            for update;

            insert into log (description) values (CONCAT('after select  accountBalance', accountBalance, ', transactionId=', old.id, ',entryId=', id, ',accountid=', accountId));

            update transactionEntry t
            set t.accountBalance = accountBalance + entryAmount, t.entryDate = new.transactionDate
            where t.id = id and t.`accountId` = accountId;

            insert into log (description) values (CONCAT('after update current with accountBalance', (accountBalance + entryAmount), ', transactionId=', old.id, ',entryId=', id, ',accountid=', accountId));

        END LOOP read_loop;
        CLOSE transactionEntriesCursor;
    END IF;
END;

