create
    definer = root@localhost procedure refresh_transactionEntry_now()
BEGIN
  TRUNCATE TABLE transactionEntry;
  INSERT INTO transactionEntry SELECT * FROM transactionEntryVI;
END;

