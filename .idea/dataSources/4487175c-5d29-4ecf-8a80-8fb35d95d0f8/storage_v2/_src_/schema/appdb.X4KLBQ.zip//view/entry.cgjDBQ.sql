create definer = root@localhost view entry as
select `accttrans`.`id`                                                                            AS `id`,
       `trans`.`id`                                                                                AS `transactionId`,
       `accttrans`.`accountId`                                                                     AS `accountId`,
       `accttrans`.`description`                                                                   AS `description`,
       `accttrans`.`status`                                                                        AS `status`,
       `trans`.`transactionDate`                                                                   AS `entryDate`,
       `accttrans`.`amount`                                                                        AS `amount`,
       (case when (`accttrans`.`amount` > 0) then `accttrans`.`amount` else 0 end)                 AS `debit`,
       (case when (`accttrans`.`amount` < 0) then (`accttrans`.`amount` * -(1)) else 0 end)        AS `credit`,
       (case
            when (coalesce(`accttrans`.`amount`, 0) > 0) then (abs(coalesce(`accttrans`.`amount`, 0)) *
                                                               coalesce(`acctt`.`debitSign`, 0))
            else (abs(coalesce(`accttrans`.`amount`, 0)) * coalesce(`acctt`.`creditSign`, 0)) end) AS `entryAmount`,
       `trans`.`voucherTypeId`                                                                     AS `sourceDocument`,
       `trans`.`code`                                                                              AS `code`
from ((((`appdb`.`accounttransaction` `accttrans` join `appdb`.`account` `acct` on ((`acct`.`id` = `accttrans`.`accountId`))) join `appdb`.`transaction` `trans` on ((`accttrans`.`transactionId` = `trans`.`id`))) join `appdb`.`accountgroup` `acctgrp` on ((`acct`.`accountGroup` = `acctgrp`.`id`)))
         join `appdb`.`accounttype` `acctt` on ((`acctt`.`id` = `acctgrp`.`accountType`)));

