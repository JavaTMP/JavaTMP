create definer = root@localhost view transactionentryvi_1 as
select `entry`.`id`                                                                                                              AS `id`,
       `entry`.`transactionId`                                                                                                   AS `transactionId`,
       `entry`.`accountId`                                                                                                       AS `accountId`,
       `entry`.`description`                                                                                                     AS `description`,
       `entry`.`status`                                                                                                          AS `status`,
       `entry`.`entryDate`                                                                                                       AS `entryDate`,
       `entry`.`amount`                                                                                                          AS `amount`,
       `entry`.`debit`                                                                                                           AS `debit`,
       `entry`.`credit`                                                                                                          AS `credit`,
       `entry`.`entryAmount`                                                                                                     AS `entryAmount`,
       `entry`.`sourceDocument`                                                                                                  AS `sourceDocument`,
       `entry`.`code`                                                                                                            AS `code`,
       sum(`entry`.`entryAmount`)
           OVER (PARTITION BY `entry`.`accountId` ORDER BY `entry`.`entryDate` ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS `accountBalance`
from `appdb`.`entry`;

