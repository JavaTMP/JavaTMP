package com.javatmp.module.content.repository;

import com.javatmp.fw.data.jpa.repository.ExtendedJpaRepository;
import com.javatmp.module.content.entity.Content;

/**
 *
 * @author JavaTMP
 */
public interface ContentRepository extends ExtendedJpaRepository<Content, Long> {

}
