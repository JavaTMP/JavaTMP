drop table if exists activity;
drop table IF EXISTS user;
drop table IF EXISTS document;
drop table IF EXISTS country;
drop table IF EXISTS language;
drop table IF EXISTS timezone;
drop table IF EXISTS theme;
