
CREATE DATABASE IF NOT EXISTS appdb;
USE appdb;

source drop_tables.sql
source create_tables.sql
source insert_tables.sql


